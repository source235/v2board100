<html><head></head><body><div style="background:#eaeaea;padding:0;margin:0">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tbody>
            <tr>
                <td style="background:#eaeaea" class="m_1715600592293973184content_container" bgcolor="#EAEAEA">
                    <table border="0" align="center" cellpadding="0" cellspacing="0" class="m_1715600592293973184font_warp">
                        <tbody>
                            <tr>
                                <td style="padding:5px" class="m_1715600592293973184content_head_warp">
                                    <div style="color:#666666">
                                        <p>
                                            <br></p>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table border="0" align="center" cellpadding="0" cellspacing="0" class="m_1715600592293973184body_warp">
                        <tbody>
                            <tr>
                                <td height="0" style="height:0px" valign="bottom"></td>
                            </tr>
                            <tr>
                                <td align="center" valign="top">
                                    <table border="0" align="center" cellpadding="0" cellspacing="0" class="m_1715600592293973184font_warp">
                                        <tbody>
                                            <tr>
                                                <td bgcolor="#FFFFFF">
                                                    <table border="0" align="left" cellpadding="0" cellspacing="0" class="m_1715600592293973184font_content_container_warp">
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <table border="0" cellspacing="0" cellpadding="0" class="m_1715600592293973184font_warp">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td align="left" style="background-color:none;padding-top:0px;padding-bottom:0px">
                                                                                    <img src="https://ci6.googleusercontent.com/proxy/_x3OhDQ6Q22scwCCGZFEFjszj594uF0yy8bJkpwtZn7cPlJ-OIh3nFBvp-Nwb88oCXGKFVzBa4bRhKe57DjsngDyhcusu538eG8Kxo3tUoVb2Y5kTj1cTc3LyceRBRiGfwcGdZRejYfwMjWu47-DqUkIAbKVmIhXB_MQUouPfG-DqUwmXHdONB4d75MxH0wa4M-LQ0zC1trH3agyQ-KzSwsgcr8LKOydBA=s0-d-e1-ft#https://libraries.mysubmail.com/public/5adf532f109dc85fb3a4637105cdeaae/trigger/8f6063bf124c1df3a35968fea807da41/292099d23f1871e4d9fc4f13634bfcca.png" border="0" style="width:100%;height:auto;margin:0px 0px 0px 0px;border-style:none;border-color:#333333;border-width:0px" alt="" class="CToWUd a6T" tabindex="0">
                                                                                    <div class="a6S" dir="ltr" style="opacity: 0.01; left: 840px; top: 254px;">
                                                                                        <div id=":2pp" class="T-I J-J5-Ji aQv T-I-ax7 L3 a5q" role="button" tabindex="0" aria-label="下载附件“”" data-tooltip-class="a1V" data-tooltip="下载">
                                                                                            <div class="aSK J-J5-Ji aYr"></div>
                                                                                        </div>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <table border="0" cellspacing="0" cellpadding="0" class="m_1715600592293973184font_warp" style="
    width: 100%;
">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td style="background-color:none;padding-top:10px;padding-bottom:10px">
                                                                                    <table border="0" cellspacing="0" cellpadding="0" class="m_1715600592293973184font_warp" style="
    width: 100%;
">
                                                                                        <tbody>
                                                                                            <tr>
                                                                                                <td align="left">
                                                                                                    <div style="text-align: center;font-size:12px;background-color:rgba(0,0,0,0);color:#333333;margin: 0px 30px 30px 30px;padding:0px 0px 0px 0px;border-style:none;border-color:#333333;border-width:0px;">
                                                                                                        <p style="text-align:center">
                                                                                                            <br></p>
                                                                                                        <p style="text-align:center">
                                                                                                            <span style="color:#69707a">
                                                                                                                <span style="font-family:tahoma,geneva,sans-serif">
                                                                                                                    <span style="font-size:16px">感谢您使用「{{$name}}」，请在 10 分钟内填写验证码完成验证操作。</span></span>
                                                                                                            </span>
                                                                                                        </p>
                                                                                                        <p style="text-align:center">
                                                                                                            <span style="color:#69707a">
                                                                                                                <span style="font-family:tahoma,geneva,sans-serif">
                                                                                                                    <span style="font-size:16px"></span>
                                                                                                                </span>
                                                                                                            </span>
                                                                                                            <br></p>
                                                                                                        <p style="text-align:center">
                                                                                                            <span style="font-size:48px">
                                                                                                                <span style="color:#69707a">
                                                                                                                    <span style="font-family:tahoma,geneva,sans-serif">{{$code}}</span></span>
                                                                                                            </span>
                                                                                                        </p>
                                                                                                    </div>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            
                                                            
                                                            
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td height="0" style="height:0px" valign="top"></td>
                            </tr>
                        </tbody>
                    </table>
                    <table border="0" align="center" cellpadding="0" cellspacing="0" style="padding:40px 0" class="m_1715600592293973184font_warp">
                        <tbody>
                            <tr>
                                <td style="padding:10px 5px" class="m_1715600592293973184content_head_warp">
                                    <div style="color:#999999">
                                        <div style="text-align:center">※ 请勿回复此邮件</div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    <div style="width:0px;height:0px;display:none">
        <img src="https://ci4.googleusercontent.com/proxy/ISedNJkQ1X_Y6XMIsG1Q7mCyv5R6B20MK808KVJYqUm6ng5A7z_N-WiPXbFqHM99F3ml_AflIhS9UwVgQIyorU0SuRdpyTZL_Vp_WWgAK4O9QW0dtGJsNqLjxJljQiDbeavwzzH3gmtAXtfel36esm2Or07vvUVs1fRCotY659TDaLlnqu73x9dv8oiWx37Lg5StTXgPzWVqNtdre-nek3FiFaVSiH-N1ELGoQTT4GpRL3kJsSGpmsMyK-WwfB1Ee5jvmTWVQvo0OUZJeQLVC9QGNZdg3Di2IsIdHAPclvAQbQ=s0-d-e1-ft#http://subtracker.submail.cn/tritracking?t=eb976d3714b640654a7067fe8152dc11b445850ecab76b2db57ed4d6710648b3&amp;i=ba12c428a8147d13bd23fbbbc46fd8e5ad472c34fcbff206cf734ebaf69af7c38e4a17916b70e9f144c9067b3f9f5306" width="1" height="1" alt="subtracker" class="CToWUd"></div>
</div></body></html>