window.v2board = {
  title: 'V2Board',
  theme: '1',
  host: ''
}
