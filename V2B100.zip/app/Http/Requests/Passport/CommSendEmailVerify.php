<?php

namespace App\Http\Requests\Passport;

use Illuminate\Foundation\Http\FormRequest;

class CommSendEmailVerify extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'email' => 'required|email'
        ];
    }
    
    public function messages()
    {
        return [
            'email.required' => '邮箱不能为空',
            'email.email'  => '邮箱格式不正确'
        ];
    }
}
